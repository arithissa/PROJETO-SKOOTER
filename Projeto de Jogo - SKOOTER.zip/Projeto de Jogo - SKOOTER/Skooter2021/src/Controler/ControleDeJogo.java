package Controler;

import Modelo.Elemento;
import Modelo.Hero;
import Auxiliar.Posicao;
import java.util.ArrayList;


public class ControleDeJogo {

    public void desenhaTudo(ArrayList<Elemento> e) {
        for (int i = 0; i < e.size(); i++) {
            e.get(i).autoDesenho();
        }
    }

    public void processaTudo(ArrayList<Elemento> e) {
        Hero hHero = (Hero) e.get(0);
        /*O heroi (protagonista) eh sempre o primeiro do array*/
        Elemento eTemp;
        /*Processa todos os demais em relacao ao heroi*/
        for (int i = 1; i < e.size(); i++) {
            eTemp = e.get(i);
            /*Pega o i-esimo elemento do jogo*/
 /*Verifica se o heroi se sobrepoe ao i-ésimo elemento*/
            if (hHero.getPosicao().estaNaMesmaPosicao(eTemp.getPosicao())) /*Nem todos os elementos podem ser transpostos pelo heroi*/ {
                if (!eTemp.isbTransponivel() && eTemp.isbMortal()) { /*Se é monstrinho*/
                    hHero.setVidas(hHero.getVidas() - 1);
                    System.out.println("Você perdeu uma vida!\nTotal de vidas: " + hHero.getVidas() + "\n");
                    e.remove(eTemp);
                }
                if (eTemp.isbColecionavel()) { /*Se é cogumelo*/
                    hHero.setPontos(hHero.getPontos() + 1);
                    System.out.println("Você pegou um colecionável!\nTotal de pontos: " + hHero.getPontos() + "\n");
                    e.remove(eTemp);
                }
                if (eTemp.isbTransponivel() && !eTemp.isbMortal()) { /*Se é seta*/
                    int direcaoTemp = eTemp.getDirecao();
                    switch(direcaoTemp) {
                        case 0:
                            hHero.moveUp();
                            break;
                        case 1:
                            hHero.moveDown();
                            break;
                        case 2:
                            hHero.moveRight();
                            break;
                        case 3:
                            hHero.moveLeft();
                            break;
                    }
                }
                if (eTemp.isbTransponivel() && eTemp.isbMortal() && !eTemp.isbColecionavel()) { /*Se é vida*/
                    hHero.setVidas(hHero.getVidas() + 1);
                    System.out.println("Você ganhou uma vida!\nTotal de vidas: " + hHero.getVidas() + "\n");
                    e.remove(eTemp);
                }
            }
        }
    }
    
    public Elemento ehPosicaoValidaHeroi(ArrayList<Elemento> e, Posicao p) {
        Elemento eTemp = null;
        /*Validacao da posicao de todos os elementos com relacao a Posicao p*/
        for (int i = 1; i < e.size(); i++) {
            /*Olha todos os elementos*/
            eTemp = e.get(i);
            /*Pega o i-esimo elemento do jogo*/
            if (!eTemp.isbTransponivel()) {
                if (eTemp.getPosicao().estaNaMesmaPosicao(p)) {
                    return eTemp; /*A posicao p é invalida, pois ha um elemento (i-esimo eTemp) intransponivel lá*/
                }
            }
        }
        return null;
    }
    
    public Elemento ehPosicaoValidaGeral(ArrayList<Elemento> e, Elemento umElemento) {
        Elemento eTemp = null;
        /*Validacao da posicao de todos os elementos com relacao a Posicao p*/
        for (int i = 1; i < e.size(); i++) {
            /*Olha todos os elementos*/
            eTemp = e.get(i);
            /*Pega o i-esimo elemento do jogo*/
            if (eTemp == umElemento) {
                continue;
            }
            if (!eTemp.isbTransponivel()) {
                if (eTemp.getPosicao().estaNaMesmaPosicao(umElemento.getPosicao())) {
                    return eTemp; /*A posicao p é invalida, pois ha um elemento (i-esimo eTemp) intransponivel lá*/
                }
            }
            if (eTemp.isbTransponivel() && !eTemp.isbMortal()) {
                if (eTemp.getPosicao().estaNaMesmaPosicao(umElemento.getPosicao())) {
                    return eTemp; /*A posicao p é invalida, pois ha uma seta lá*/
                }
            }
        }
        return null;
    }
    
    public Elemento searchElemento(ArrayList<Elemento> e, Posicao p) {
        Elemento eTemp = null;
        
        for (int i = 1; i < e.size(); i++) {
            eTemp = e.get(i);
            if (eTemp.getPosicao().estaNaMesmaPosicao(p)) {
                return eTemp;
            }
        }
        return null;
    }
    
    public int contadorDeCogumelos(ArrayList<Elemento> e) {
        int contadorCogumelos = 0;
        for (int i = 1; i < e.size(); i++) {
            if (e.get(i).isbColecionavel()) {
                contadorCogumelos++;
            }
        }
        return contadorCogumelos;
    }
}
