
package Controler;

import Auxiliar.Consts;
import Auxiliar.Desenhador;
import Auxiliar.Posicao;
import Modelo.BlocoFixoComum;
import Modelo.BlocoFixoExplosivo;
import Modelo.BlocoMovelComum;
import Modelo.BlocoMovelExplosivo;
import Modelo.Cogumelo;
import Modelo.Elemento;
import Modelo.Hero;
import Modelo.Monstrinho;
import Modelo.Seta;
import Modelo.Vida;
import java.util.ArrayList;


public class Fase extends ArrayList<Elemento> {
    private ControleDeJogo cControle = new ControleDeJogo();
    
    Fase(int tFase){
        super(tFase);
    }
    
    public void setFase1(Hero hHero){
        this.clear();
        this.add(hHero);
        BlocoFixoComum b1 = new BlocoFixoComum("bloco-fixo-comum.png");
        b1.setPosicao(1, 1);
        this.add(b1);

        BlocoFixoComum b2 = new BlocoFixoComum("bloco-fixo-comum.png");
        b2.setPosicao(1, 3);
        this.add(b2);

        BlocoFixoComum b3 = new BlocoFixoComum("bloco-fixo-comum.png");
        b3.setPosicao(1, 5);
        this.add(b3);
        
        BlocoFixoComum b4 = new BlocoFixoComum("bloco-fixo-comum.png");
        b4.setPosicao(1, 7);
        this.add(b4);

        BlocoFixoComum b5 = new BlocoFixoComum("bloco-fixo-comum.png");
        b5.setPosicao(1, 9);
        this.add(b5);

        BlocoFixoComum b6 = new BlocoFixoComum("bloco-fixo-comum.png");
        b6.setPosicao(3, 1);
        this.add(b6);

        BlocoFixoComum b7 = new BlocoFixoComum("bloco-fixo-comum.png");
        b7.setPosicao(3, 3);
        this.add(b7);

        BlocoFixoComum b8 = new BlocoFixoComum("bloco-fixo-comum.png");
        b8.setPosicao(3, 5);
        this.add(b8);

        BlocoFixoComum b9 = new BlocoFixoComum("bloco-fixo-comum.png");
        b9.setPosicao(3, 7);
        this.add(b9);

        BlocoFixoComum b10 = new BlocoFixoComum("bloco-fixo-comum.png");
        b10.setPosicao(3, 9);
        this.add(b10);

        BlocoFixoComum b11 = new BlocoFixoComum("bloco-fixo-comum.png");
        b11.setPosicao(5, 1);
        this.add(b11);

        BlocoFixoComum b12 = new BlocoFixoComum("bloco-fixo-comum.png");
        b12.setPosicao(5, 3);
        this.add(b12);

        BlocoFixoComum b13 = new BlocoFixoComum("bloco-fixo-comum.png");
        b13.setPosicao(5, 5);
        this.add(b13);

        BlocoFixoComum b14 = new BlocoFixoComum("bloco-fixo-comum.png");
        b14.setPosicao(5, 7);
        this.add(b14);

        BlocoFixoComum b15 = new BlocoFixoComum("bloco-fixo-comum.png");
        b15.setPosicao(5, 9);
        this.add(b15);

        BlocoFixoComum b16 = new BlocoFixoComum("bloco-fixo-comum.png");
        b16.setPosicao(7, 1);
        this.add(b16);

        BlocoFixoComum b17 = new BlocoFixoComum("bloco-fixo-comum.png");
        b17.setPosicao(7, 3);
        this.add(b17);

        BlocoFixoComum b18 = new BlocoFixoComum("bloco-fixo-comum.png");
        b18.setPosicao(7, 5);
        this.add(b18);

        BlocoFixoComum b19 = new BlocoFixoComum("bloco-fixo-comum.png");
        b19.setPosicao(7, 7);
        this.add(b19);

        BlocoFixoComum b20 = new BlocoFixoComum("bloco-fixo-comum.png");
        b20.setPosicao(7, 9);
        this.add(b20);

        BlocoFixoComum b21 = new BlocoFixoComum("bloco-fixo-comum.png");
        b21.setPosicao(9, 1);
        this.add(b21);
        
        BlocoFixoComum b22 = new BlocoFixoComum("bloco-fixo-comum.png");
        b22.setPosicao(9, 3);
        this.add(b22);

        BlocoFixoComum b23 = new BlocoFixoComum("bloco-fixo-comum.png");
        b23.setPosicao(9, 5);
        this.add(b23);

        BlocoFixoComum b24 = new BlocoFixoComum("bloco-fixo-comum.png");
        b24.setPosicao(9, 7);
        this.add(b24);

        BlocoFixoComum b25 = new BlocoFixoComum("bloco-fixo-comum.png");
        b25.setPosicao(9, 9);
        this.add(b25);

        BlocoMovelExplosivo bm1 = new BlocoMovelExplosivo("bloco-movel-explosivo.png");
        bm1.setPosicao(0, 1);
        this.add(bm1);

        BlocoMovelExplosivo bm2 = new BlocoMovelExplosivo("bloco-movel-explosivo.png");
        bm2.setPosicao(0, 5);
        this.add(bm2);

        BlocoMovelExplosivo bm3 = new BlocoMovelExplosivo("bloco-movel-explosivo.png");
        bm3.setPosicao(1, 2);
        this.add(bm3);

        BlocoMovelExplosivo bm4 = new BlocoMovelExplosivo("bloco-movel-explosivo.png");
        bm4.setPosicao(1, 8);
        this.add(bm4);

        BlocoMovelExplosivo bm5 = new BlocoMovelExplosivo("bloco-movel-explosivo.png");
        bm5.setPosicao(1, 10);
        this.add(bm5);

        BlocoMovelExplosivo bm6 = new BlocoMovelExplosivo("bloco-movel-explosivo.png");
        bm6.setPosicao(2, 1);
        this.add(bm6);

        BlocoMovelExplosivo bm7 = new BlocoMovelExplosivo("bloco-movel-explosivo.png");
        bm7.setPosicao(2, 5);
        this.add(bm7);

        BlocoMovelExplosivo bm8 = new BlocoMovelExplosivo("bloco-movel-explosivo.png");
        bm8.setPosicao(3, 0);
        this.add(bm8);

        BlocoMovelExplosivo bm9 = new BlocoMovelExplosivo("bloco-movel-explosivo.png");
        bm9.setPosicao(3, 8);
        this.add(bm9);

        BlocoMovelExplosivo bm10 = new BlocoMovelExplosivo("bloco-movel-explosivo.png");
        bm10.setPosicao(4, 1);
        this.add(bm10);

        BlocoMovelExplosivo bm11 = new BlocoMovelExplosivo("bloco-movel-explosivo.png");
        bm11.setPosicao(4, 9);
        this.add(bm11);

        BlocoMovelExplosivo bm12 = new BlocoMovelExplosivo("bloco-movel-explosivo.png");
        bm12.setPosicao(5, 2);
        this.add(bm12);

        BlocoMovelExplosivo bm13 = new BlocoMovelExplosivo("bloco-movel-explosivo.png");
        bm13.setPosicao(5, 6);
        this.add(bm13);

        BlocoMovelExplosivo bm14 = new BlocoMovelExplosivo("bloco-movel-explosivo.png");
        bm14.setPosicao(6, 5);
        this.add(bm14);

        BlocoMovelExplosivo bm15 = new BlocoMovelExplosivo("bloco-movel-explosivo.png");
        bm15.setPosicao(6, 7);
        this.add(bm15);

        BlocoMovelExplosivo bm16 = new BlocoMovelExplosivo("bloco-movel-explosivo.png");
        bm16.setPosicao(7, 8);
        this.add(bm16);

        BlocoMovelExplosivo bm17 = new BlocoMovelExplosivo("bloco-movel-explosivo.png");
        bm17.setPosicao(7, 10);
        this.add(bm17);

        BlocoMovelExplosivo bm18 = new BlocoMovelExplosivo("bloco-movel-explosivo.png");
        bm18.setPosicao(8, 3);
        this.add(bm18);

        BlocoMovelExplosivo bm19 = new BlocoMovelExplosivo("bloco-movel-explosivo.png");
        bm19.setPosicao(8, 9);
        this.add(bm19);

        BlocoMovelExplosivo bm20 = new BlocoMovelExplosivo("bloco-movel-explosivo.png");
        bm20.setPosicao(9, 2);
        this.add(bm20);

        BlocoMovelExplosivo bm21 = new BlocoMovelExplosivo("bloco-movel-explosivo.png");
        bm21.setPosicao(9, 6);
        this.add(bm21);

        BlocoMovelExplosivo bm22 = new BlocoMovelExplosivo("bloco-movel-explosivo.png");
        bm22.setPosicao(9, 8);
        this.add(bm22);

        BlocoMovelExplosivo bm23 = new BlocoMovelExplosivo("bloco-movel-explosivo.png");
        bm23.setPosicao(10, 7);
        this.add(bm23);

        Cogumelo c1 = new Cogumelo("cogumelo.png");
        c1.setPosicao(0, 0);
        this.add(c1);

        Cogumelo c2 = new Cogumelo("cogumelo.png");
        c2.setPosicao(0, 10);
        this.add(c2);

        Cogumelo c3 = new Cogumelo("cogumelo.png");
        c3.setPosicao(10, 0);
        this.add(c3);

        Cogumelo c4 = new Cogumelo("cogumelo.png");
        c4.setPosicao(10, 10);
        this.add(c4);

        Monstrinho m1 = new Monstrinho("monstrinho.png");
        m1.setPosicao(0, 9);
        this.add(m1);

        Monstrinho m2 = new Monstrinho("monstrinho.png");
        m2.setPosicao(2, 0);
        this.add(m2);

        Monstrinho m3 = new Monstrinho("monstrinho.png");
        m3.setPosicao(10, 1);
        this.add(m3);

        Monstrinho m4 = new Monstrinho("monstrinho.png");
        m4.setPosicao(10, 9);
        this.add(m4);
        
        Vida v1 = new Vida("vida.png", hHero);
        v1.setPosicao(9, 0);
        this.add(v1);
    }
    
    public void setFase2(Hero hHero){
        this.clear();
        this.add(hHero);

        BlocoFixoComum b1 = new BlocoFixoComum("bloco-fixo-comum.png");
        b1.setPosicao(1, 3);
        this.add(b1);

        BlocoFixoComum b2 = new BlocoFixoComum("bloco-fixo-comum.png");
        b2.setPosicao(1, 7);
        this.add(b2);

        BlocoFixoComum b3 = new BlocoFixoComum("bloco-fixo-comum.png");
        b3.setPosicao(3, 1);
        this.add(b3);
        
        BlocoFixoComum b4 = new BlocoFixoComum("bloco-fixo-comum.png");
        b4.setPosicao(3, 3);
        this.add(b4);

        BlocoFixoComum b5 = new BlocoFixoComum("bloco-fixo-comum.png");
        b5.setPosicao(3, 5);
        this.add(b5);

        BlocoFixoComum b6 = new BlocoFixoComum("bloco-fixo-comum.png");
        b6.setPosicao(3, 7);
        this.add(b6);

        BlocoFixoComum b7 = new BlocoFixoComum("bloco-fixo-comum.png");
        b7.setPosicao(3, 9);
        this.add(b7);

        BlocoFixoComum b8 = new BlocoFixoComum("bloco-fixo-comum.png");
        b8.setPosicao(5, 3);
        this.add(b8);

        BlocoFixoComum b9 = new BlocoFixoComum("bloco-fixo-comum.png");
        b9.setPosicao(5, 7);
        this.add(b9);

        BlocoFixoComum b10 = new BlocoFixoComum("bloco-fixo-comum.png");
        b10.setPosicao(7, 1);
        this.add(b10);

        BlocoFixoComum b11 = new BlocoFixoComum("bloco-fixo-comum.png");
        b11.setPosicao(7, 3);
        this.add(b11);

        BlocoFixoComum b12 = new BlocoFixoComum("bloco-fixo-comum.png");
        b12.setPosicao(7, 5);
        this.add(b12);

        BlocoFixoComum b13 = new BlocoFixoComum("bloco-fixo-comum.png");
        b13.setPosicao(7, 7);
        this.add(b13);

        BlocoFixoComum b14 = new BlocoFixoComum("bloco-fixo-comum.png");
        b14.setPosicao(7, 9);
        this.add(b14);

        BlocoFixoComum b15 = new BlocoFixoComum("bloco-fixo-comum.png");
        b15.setPosicao(9, 3);
        this.add(b15);

        BlocoFixoComum b16 = new BlocoFixoComum("bloco-fixo-comum.png");
        b16.setPosicao(9, 7);
        this.add(b16);
        
        Cogumelo c1 = new Cogumelo("cogumelo.png");
        c1.setPosicao(1, 5);
        this.add(c1);

        Cogumelo c2 = new Cogumelo("cogumelo.png");
        c2.setPosicao(5, 1);
        this.add(c2);

        Cogumelo c3 = new Cogumelo("cogumelo.png");
        c3.setPosicao(5, 9);
        this.add(c3);

        Cogumelo c4 = new Cogumelo("cogumelo.png");
        c4.setPosicao(9, 5);
        this.add(c4);
        
        Monstrinho m1 = new Monstrinho("monstrinho.png");
        m1.setPosicao(1, 1);
        this.add(m1);

        Monstrinho m2 = new Monstrinho("monstrinho.png");
        m2.setPosicao(1, 9);
        this.add(m2);

        Monstrinho m3 = new Monstrinho("monstrinho.png");
        m3.setPosicao(9, 1);
        this.add(m3);

        Monstrinho m4 = new Monstrinho("monstrinho.png");
        m4.setPosicao(9, 9);
        this.add(m4);
        
        Seta s1 = new Seta("seta-pra-direita.png", 2, hHero);
        s1.setPosicao(0, 3);
        this.add(s1);
        
        Seta s2 = new Seta("seta-pra-direita.png", 2, hHero);
        s2.setPosicao(0, 7);
        this.add(s2);
        
        Seta s3 = new Seta("seta-pra-direita.png", 2, hHero);
        s3.setPosicao(2, 3);
        this.add(s3);
        
        Seta s4 = new Seta("seta-pra-baixo.png", 1, hHero);
        s4.setPosicao(2, 4);
        this.add(s4);
        
        Seta s5 = new Seta("seta-pra-esquerda.png", 3, hHero);
        s5.setPosicao(2, 5);
        this.add(s5);
        
        Seta s6 = new Seta("seta-pra-esquerda.png", 3, hHero);
        s6.setPosicao(2, 6);
        this.add(s6);
        
        Seta s7 = new Seta("seta-pra-esquerda.png", 3, hHero);
        s7.setPosicao(2, 7);
        this.add(s7);
        
        Seta s8 = new Seta("seta-pra-cima.png", 0, hHero);
        s8.setPosicao(3, 0);
        this.add(s8);
        
        Seta s9 = new Seta("seta-pra-baixo.png", 1, hHero);
        s9.setPosicao(3, 2);
        this.add(s9);
        
        Seta s10 = new Seta("seta-pra-baixo.png", 1, hHero);
        s10.setPosicao(3, 4);
        this.add(s10);
        
        Seta s11 = new Seta("seta-pra-cima.png", 0, hHero);
        s11.setPosicao(3, 6);
        this.add(s11);
        
        Seta s12 = new Seta("seta-pra-cima.png", 0, hHero);
        s12.setPosicao(3, 8);
        this.add(s12);
        
        Seta s13 = new Seta("seta-pra-baixo.png", 1, hHero);
        s13.setPosicao(3, 10);
        this.add(s13);
        
        Seta s14 = new Seta("seta-pra-cima.png", 0, hHero);
        s14.setPosicao(4, 0);
        this.add(s14);
        
        Seta s15 = new Seta("seta-pra-direita.png", 2, hHero);
        s15.setPosicao(4, 3);
        this.add(s15);
        
        Seta s16 = new Seta("seta-pra-direita.png", 2, hHero);
        s16.setPosicao(4, 7);
        this.add(s16);
        
        Seta s17 = new Seta("seta-pra-cima.png", 0, hHero);
        s17.setPosicao(4, 8);
        this.add(s17);
        
        Seta s18 = new Seta("seta-pra-esquerda.png", 3, hHero);
        s18.setPosicao(4, 9);
        this.add(s18);
        
        Seta s19 = new Seta("seta-pra-esquerda.png", 3, hHero);
        s19.setPosicao(4, 10);
        this.add(s19);
        
        Seta s20 = new Seta("seta-pra-cima.png", 0, hHero);
        s20.setPosicao(5, 0);
        this.add(s20);
        
        Seta s21 = new Seta("seta-pra-cima.png", 0, hHero);
        s21.setPosicao(6, 0);
        this.add(s21);
        
        Seta s22 = new Seta("seta-pra-direita.png", 2, hHero);
        s22.setPosicao(6, 3);
        this.add(s22);
        
        Seta s23 = new Seta("seta-pra-esquerda.png", 3, hHero);
        s23.setPosicao(6, 7);
        this.add(s23);
        
        Seta s24 = new Seta("seta-pra-cima.png", 0, hHero);
        s24.setPosicao(7, 0);
        this.add(s24);
        
        Seta s25 = new Seta("seta-pra-baixo.png", 1, hHero);
        s25.setPosicao(7, 2);
        this.add(s25);
        
        Seta s26 = new Seta("seta-pra-baixo.png", 1, hHero);
        s26.setPosicao(7, 4);
        this.add(s26);
        
        Seta s27 = new Seta("seta-pra-cima.png", 0, hHero);
        s27.setPosicao(7, 6);
        this.add(s27);
        
        Seta s28 = new Seta("seta-pra-cima.png", 0, hHero);
        s28.setPosicao(7, 8);
        this.add(s28);
        
        Seta s29 = new Seta("seta-pra-cima.png", 0, hHero);
        s29.setPosicao(7, 10);
        this.add(s29);
        
        Seta s30 = new Seta("seta-pra-direita.png", 2, hHero);
        s30.setPosicao(8, 3);
        this.add(s30);
        
        Seta s31 = new Seta("seta-pra-direita.png", 2, hHero);
        s31.setPosicao(8, 7);
        this.add(s31);
        
        Seta s32 = new Seta("seta-pra-esquerda.png", 3, hHero);
        s32.setPosicao(10, 3);
        this.add(s32);
        
        Seta s33 = new Seta("seta-pra-direita.png", 2, hHero);
        s33.setPosicao(10, 7);
        this.add(s33);
        
        Vida v1 = new Vida("vida.png", hHero);
        v1.setPosicao(10, 5);
        this.add(v1);
    }
    
    public void setFase3(Hero hHero){
        this.clear();
        this.add(hHero);

        BlocoMovelComum b1 = new BlocoMovelComum("bloco-movel-comum.png");
        b1.setPosicao(1, 1);
        this.add(b1);

        BlocoMovelComum b2 = new BlocoMovelComum("bloco-movel-comum.png");
        b2.setPosicao(1, 2);
        this.add(b2);

        BlocoMovelComum b3 = new BlocoMovelComum("bloco-movel-comum.png");
        b3.setPosicao(1, 3);
        this.add(b3);

        BlocoMovelComum b4 = new BlocoMovelComum("bloco-movel-comum.png");
        b4.setPosicao(1, 4);
        this.add(b4);

        BlocoMovelComum b5 = new BlocoMovelComum("bloco-movel-comum.png");
        b5.setPosicao(1, 5);
        this.add(b5);

        BlocoMovelComum b6 = new BlocoMovelComum("bloco-movel-comum.png");
        b6.setPosicao(1, 6);
        this.add(b6);

        BlocoMovelComum b7 = new BlocoMovelComum("bloco-movel-comum.png");
        b7.setPosicao(1, 7);
        this.add(b7);

        BlocoMovelComum b8 = new BlocoMovelComum("bloco-movel-comum.png");
        b8.setPosicao(1, 8);
        this.add(b8);

        BlocoMovelComum b9 = new BlocoMovelComum("bloco-movel-comum.png");
        b9.setPosicao(1, 9);
        this.add(b9);

        BlocoMovelComum b10 = new BlocoMovelComum("bloco-movel-comum.png");
        b10.setPosicao(2, 1);
        this.add(b10);

        BlocoMovelComum b11 = new BlocoMovelComum("bloco-movel-comum.png");
        b11.setPosicao(2, 9);
        this.add(b11);

        BlocoMovelComum b12 = new BlocoMovelComum("bloco-movel-comum.png");
        b12.setPosicao(3, 1);
        this.add(b12);

        BlocoMovelComum b13 = new BlocoMovelComum("bloco-movel-comum.png");
        b13.setPosicao(3, 3);
        this.add(b13);

        BlocoMovelComum b14 = new BlocoMovelComum("bloco-movel-comum.png");
        b14.setPosicao(3, 4);
        this.add(b14);

        BlocoMovelComum b15 = new BlocoMovelComum("bloco-movel-comum.png");
        b15.setPosicao(3, 5);
        this.add(b15);

        BlocoMovelComum b16 = new BlocoMovelComum("bloco-movel-comum.png");
        b16.setPosicao(3, 6);
        this.add(b16);

        BlocoMovelComum b17 = new BlocoMovelComum("bloco-movel-comum.png");
        b17.setPosicao(3, 7);
        this.add(b17);

        BlocoMovelComum b18 = new BlocoMovelComum("bloco-movel-comum.png");
        b18.setPosicao(3, 9);
        this.add(b18);

        BlocoMovelComum b19 = new BlocoMovelComum("bloco-movel-comum.png");
        b19.setPosicao(4, 1);
        this.add(b19);
        
        BlocoMovelComum b20 = new BlocoMovelComum("bloco-movel-comum.png");
        b20.setPosicao(4, 3);
        this.add(b20);
        
        BlocoMovelComum b21 = new BlocoMovelComum("bloco-movel-comum.png");
        b21.setPosicao(4, 7);
        this.add(b21);
        
        BlocoMovelComum b22 = new BlocoMovelComum("bloco-movel-comum.png");
        b22.setPosicao(4, 9);
        this.add(b22);
        
        BlocoMovelComum b23 = new BlocoMovelComum("bloco-movel-comum.png");
        b23.setPosicao(5, 1);
        this.add(b23);
        
        BlocoMovelComum b24 = new BlocoMovelComum("bloco-movel-comum.png");
        b24.setPosicao(5, 3);
        this.add(b24);
        
        BlocoMovelComum b25 = new BlocoMovelComum("bloco-movel-comum.png");
        b25.setPosicao(5, 7);
        this.add(b25);
        
        BlocoMovelComum b26 = new BlocoMovelComum("bloco-movel-comum.png");
        b26.setPosicao(5, 9);
        this.add(b26);
        
        BlocoMovelComum b27 = new BlocoMovelComum("bloco-movel-comum.png");
        b27.setPosicao(6, 1);
        this.add(b27);
        
        BlocoMovelComum b28 = new BlocoMovelComum("bloco-movel-comum.png");
        b28.setPosicao(6, 3);
        this.add(b28);
        
        BlocoMovelComum b29 = new BlocoMovelComum("bloco-movel-comum.png");
        b29.setPosicao(6, 7);
        this.add(b29);

        BlocoMovelComum b30 = new BlocoMovelComum("bloco-movel-comum.png");
        b30.setPosicao(6, 9);
        this.add(b30);

        BlocoMovelComum b31 = new BlocoMovelComum("bloco-movel-comum.png");
        b31.setPosicao(7, 1);
        this.add(b31);

        BlocoMovelComum b32 = new BlocoMovelComum("bloco-movel-comum.png");
        b32.setPosicao(7, 3);
        this.add(b32);

        BlocoMovelComum b33 = new BlocoMovelComum("bloco-movel-comum.png");
        b33.setPosicao(7, 4);
        this.add(b33);

        BlocoMovelComum b34 = new BlocoMovelComum("bloco-movel-comum.png");
        b34.setPosicao(7, 5);
        this.add(b34);

        BlocoMovelComum b35 = new BlocoMovelComum("bloco-movel-comum.png");
        b35.setPosicao(7, 6);
        this.add(b35);

        BlocoMovelComum b36 = new BlocoMovelComum("bloco-movel-comum.png");
        b36.setPosicao(7, 7);
        this.add(b36);

        BlocoMovelComum b37 = new BlocoMovelComum("bloco-movel-comum.png");
        b37.setPosicao(7, 9);
        this.add(b37);

        BlocoMovelComum b38 = new BlocoMovelComum("bloco-movel-comum.png");
        b38.setPosicao(8, 1);
        this.add(b38);

        BlocoMovelComum b39 = new BlocoMovelComum("bloco-movel-comum.png");
        b39.setPosicao(8, 9);
        this.add(b39);

        BlocoMovelComum b40 = new BlocoMovelComum("bloco-movel-comum.png");
        b40.setPosicao(9, 1);
        this.add(b40);

        BlocoMovelComum b41 = new BlocoMovelComum("bloco-movel-comum.png");
        b41.setPosicao(9, 2);
        this.add(b41);

        BlocoMovelComum b42 = new BlocoMovelComum("bloco-movel-comum.png");
        b42.setPosicao(9, 3);
        this.add(b42);

        BlocoMovelComum b43 = new BlocoMovelComum("bloco-movel-comum.png");
        b43.setPosicao(9, 4);
        this.add(b43);

        BlocoMovelComum b44 = new BlocoMovelComum("bloco-movel-comum.png");
        b44.setPosicao(9, 5);
        this.add(b44);

        BlocoMovelComum b45 = new BlocoMovelComum("bloco-movel-comum.png");
        b45.setPosicao(9, 6);
        this.add(b45);

        BlocoMovelComum b46 = new BlocoMovelComum("bloco-movel-comum.png");
        b46.setPosicao(9, 7);
        this.add(b46);

        BlocoMovelComum b47 = new BlocoMovelComum("bloco-movel-comum.png");
        b47.setPosicao(9, 8);
        this.add(b47);

        BlocoMovelComum b48 = new BlocoMovelComum("bloco-movel-comum.png");
        b48.setPosicao(9, 9);
        this.add(b48);
        
        Monstrinho m1 = new Monstrinho("monstrinho.png");
        m1.setPosicao(0, 5);
        this.add(m1);

        Monstrinho m2 = new Monstrinho("monstrinho.png");
        m2.setPosicao(2, 5);
        this.add(m2);

        Monstrinho m3 = new Monstrinho("monstrinho.png");
        m3.setPosicao(8, 5);
        this.add(m3);

        Monstrinho m4 = new Monstrinho("monstrinho.png");
        m4.setPosicao(10, 5);
        this.add(m4);
        
        Cogumelo c1 = new Cogumelo("cogumelo.png");
        c1.setPosicao(5, 0);
        this.add(c1);

        Cogumelo c2 = new Cogumelo("cogumelo.png");
        c2.setPosicao(5, 2);
        this.add(c2);

        Cogumelo c3 = new Cogumelo("cogumelo.png");
        c3.setPosicao(5, 8);
        this.add(c3);

        Cogumelo c4 = new Cogumelo("cogumelo.png");
        c4.setPosicao(5, 10);
        this.add(c4);
        
        Vida v1 = new Vida("vida.png", hHero);
        v1.setPosicao(4, 5);
        this.add(v1);
    }
    
    public void setFase4(Hero hHero){
        this.clear();
        this.add(hHero);

        BlocoFixoComum bc1 = new BlocoFixoComum("bloco-fixo-comum.png");
        bc1.setPosicao(0, 3);
        this.add(bc1);
        
        BlocoFixoComum bc2 = new BlocoFixoComum("bloco-fixo-comum.png");
        bc2.setPosicao(0, 7);
        this.add(bc2);
        
        BlocoFixoComum bc3 = new BlocoFixoComum("bloco-fixo-comum.png");
        bc3.setPosicao(1, 0);
        this.add(bc3);
        
        BlocoFixoComum bc4 = new BlocoFixoComum("bloco-fixo-comum.png");
        bc4.setPosicao(1, 8);
        this.add(bc4);
        
        BlocoFixoComum bc5 = new BlocoFixoComum("bloco-fixo-comum.png");
        bc5.setPosicao(2, 5);
        this.add(bc5);
        
        BlocoFixoComum bc6 = new BlocoFixoComum("bloco-fixo-comum.png");
        bc6.setPosicao(3, 2);
        this.add(bc6);
        
        BlocoFixoComum bc7 = new BlocoFixoComum("bloco-fixo-comum.png");
        bc7.setPosicao(3, 10);
        this.add(bc7);
        
        BlocoFixoComum bc8 = new BlocoFixoComum("bloco-fixo-comum.png");
        bc8.setPosicao(5, 2);
        this.add(bc8);
        
        BlocoFixoComum bc9 = new BlocoFixoComum("bloco-fixo-comum.png");
        bc9.setPosicao(5, 8);
        this.add(bc9);
        
        BlocoFixoComum bc10 = new BlocoFixoComum("bloco-fixo-comum.png");
        bc10.setPosicao(6, 3);
        this.add(bc10);
        
        BlocoFixoComum bc11 = new BlocoFixoComum("bloco-fixo-comum.png");
        bc11.setPosicao(7, 0);
        this.add(bc11);
        
        BlocoFixoComum bc12 = new BlocoFixoComum("bloco-fixo-comum.png");
        bc12.setPosicao(8, 1);
        this.add(bc12);
        
        BlocoFixoComum bc13 = new BlocoFixoComum("bloco-fixo-comum.png");
        bc13.setPosicao(8, 7);
        this.add(bc13);
        
        BlocoFixoComum bc14 = new BlocoFixoComum("bloco-fixo-comum.png");
        bc14.setPosicao(8, 10);
        this.add(bc14);
        
        BlocoFixoComum bc15 = new BlocoFixoComum("bloco-fixo-comum.png");
        bc15.setPosicao(9, 1);
        this.add(bc15);
        
        BlocoFixoExplosivo be1 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be1.setPosicao(1, 1);
        this.add(be1);
        
        BlocoFixoExplosivo be2 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be2.setPosicao(1, 3);
        this.add(be2);
        
        BlocoFixoExplosivo be3 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be3.setPosicao(1, 5);
        this.add(be3);
        
        BlocoFixoExplosivo be4 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be4.setPosicao(1, 7);
        this.add(be4);
        
        BlocoFixoExplosivo be5 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be5.setPosicao(1, 9);
        this.add(be5);
        
        BlocoFixoExplosivo be6 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be6.setPosicao(2, 2);
        this.add(be6);
        
        BlocoFixoExplosivo be7 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be7.setPosicao(2, 4);
        this.add(be7);
        
        BlocoFixoExplosivo be8 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be8.setPosicao(2, 6);
        this.add(be8);
        
        BlocoFixoExplosivo be9 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be9.setPosicao(2, 8);
        this.add(be9);
        
        BlocoFixoExplosivo be10 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be10.setPosicao(3, 1);
        this.add(be10);
        
        BlocoFixoExplosivo be11 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be11.setPosicao(3, 3);
        this.add(be11);
        
        BlocoFixoExplosivo be12 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be12.setPosicao(3, 5);
        this.add(be12);
        
        BlocoFixoExplosivo be13 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be13.setPosicao(3, 7);
        this.add(be13);
        
        BlocoFixoExplosivo be14 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be14.setPosicao(3, 9);
        this.add(be14);
        
        BlocoFixoExplosivo be15 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be15.setPosicao(4, 2);
        this.add(be15);
        
        BlocoFixoExplosivo be16 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be16.setPosicao(4, 4);
        this.add(be16);
        
        BlocoFixoExplosivo be17 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be17.setPosicao(4, 6);
        this.add(be17);
        
        BlocoFixoExplosivo be18 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be18.setPosicao(4, 8);
        this.add(be18);
        
        BlocoFixoExplosivo be19 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be19.setPosicao(5, 1);
        this.add(be19);
        
        BlocoFixoExplosivo be20 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be20.setPosicao(5, 3);
        this.add(be20);
        
        BlocoFixoExplosivo be21 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be21.setPosicao(5, 5);
        this.add(be21);
        
        BlocoFixoExplosivo be22 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be22.setPosicao(5, 7);
        this.add(be22);
        
        BlocoFixoExplosivo be23 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be23.setPosicao(5, 9);
        this.add(be23);
        
        BlocoFixoExplosivo be24 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be24.setPosicao(6, 2);
        this.add(be24);
        
        BlocoFixoExplosivo be25 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be25.setPosicao(6, 4);
        this.add(be25);
        
        BlocoFixoExplosivo be26 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be26.setPosicao(6, 6);
        this.add(be26);
        
        BlocoFixoExplosivo be27 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be27.setPosicao(6, 8);
        this.add(be27);
        
        BlocoFixoExplosivo be28 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be28.setPosicao(7, 1);
        this.add(be28);
        
        BlocoFixoExplosivo be29 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be29.setPosicao(7, 3);
        this.add(be29);
        
        BlocoFixoExplosivo be30 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be30.setPosicao(7, 5);
        this.add(be30);
        
        BlocoFixoExplosivo be31 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be31.setPosicao(7, 7);
        this.add(be31);
        
        BlocoFixoExplosivo be32 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be32.setPosicao(7, 9);
        this.add(be32);
        
        BlocoFixoExplosivo be33 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be33.setPosicao(8, 2);
        this.add(be33);
        
        BlocoFixoExplosivo be34 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be34.setPosicao(8, 4);
        this.add(be34);
        
        BlocoFixoExplosivo be35 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be35.setPosicao(8, 6);
        this.add(be35);
        
        BlocoFixoExplosivo be36 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be36.setPosicao(8, 8);
        this.add(be36);
        
        BlocoFixoExplosivo be37 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be37.setPosicao(9, 1);
        this.add(be37);
        
        BlocoFixoExplosivo be38 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be38.setPosicao(9, 3);
        this.add(be38);
        
        BlocoFixoExplosivo be39 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be39.setPosicao(9, 5);
        this.add(be39);
        
        BlocoFixoExplosivo be40 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be40.setPosicao(9, 7);
        this.add(be40);
        
        BlocoFixoExplosivo be41 = new BlocoFixoExplosivo("bloco-fixo-explosivo.png");
        be41.setPosicao(9, 9);
        this.add(be41);
        
        Monstrinho m1 = new Monstrinho("monstrinho.png");
        m1.setPosicao(0, 5);
        this.add(m1);

        Monstrinho m2 = new Monstrinho("monstrinho.png");
        m2.setPosicao(5, 0);
        this.add(m2);

        Monstrinho m3 = new Monstrinho("monstrinho.png");
        m3.setPosicao(5, 10);
        this.add(m3);

        Monstrinho m4 = new Monstrinho("monstrinho.png");
        m4.setPosicao(10, 5);
        this.add(m4);
        
        Cogumelo c1 = new Cogumelo("cogumelo.png");
        c1.setPosicao(0, 0);
        this.add(c1);

        Cogumelo c2 = new Cogumelo("cogumelo.png");
        c2.setPosicao(0, 10);
        this.add(c2);

        Cogumelo c3 = new Cogumelo("cogumelo.png");
        c3.setPosicao(10, 0);
        this.add(c3);

        Cogumelo c4 = new Cogumelo("cogumelo.png");
        c4.setPosicao(10, 10);
        this.add(c4);
    }
    
    public void setFinal(Hero hHero){
        this.clear();
        this.add(hHero);
        
        BlocoFixoComum b5 = new BlocoFixoComum("you.png");
        b5.setPosicao(3, 4);
        this.add(b5);
        
        BlocoFixoComum b6 = new BlocoFixoComum("won.png");
        b6.setPosicao(3, 6);
        this.add(b6);
        
        Cogumelo c1 = new Cogumelo("cogumelo.png");
        c1.setPosicao(3, 5);
        this.add(c1);
    }
    
    public void setGameOver(Hero hHero){
        this.clear();
        this.add(hHero);
        
        BlocoFixoComum b5 = new BlocoFixoComum("game.png");
        b5.setPosicao(3, 4);
        this.add(b5);
        
        BlocoFixoComum b6 = new BlocoFixoComum("over.png");
        b6.setPosicao(3, 6);
        this.add(b6);
        
        Cogumelo c1 = new Cogumelo("cogumelo.png");
        c1.setPosicao(3, 5);
        this.add(c1);
    }
    
}
