package Modelo;

import Auxiliar.Consts;
import Auxiliar.Desenhador;
import Auxiliar.Posicao;
import Controler.ControleDeJogo;
import Controler.Fase;
import Controler.Tela;
import java.awt.Graphics;
import java.io.Serializable;
import java.util.Random;

public class Vida extends Elemento implements Serializable{
    Random r;
    
    public Vida(String sNomeImagePNG, Hero hHero) {
        super(sNomeImagePNG);
        this.bTransponivel = true;
        this.bMortal = true;
        r = new Random();
    }

    public void autoDesenho() {
        super.autoDesenho();
    }    
}