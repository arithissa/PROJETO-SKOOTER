package Modelo;

import Auxiliar.Consts;
import Auxiliar.Desenhador;
import Auxiliar.Posicao;
import Controler.ControleDeJogo;
import Controler.Fase;
import Controler.Tela;
import java.awt.Graphics;
import java.io.Serializable;
import java.util.Random;

public class Seta extends Elemento implements Serializable{
    
    int iDirecao = -1;
    Hero auxHero = null;
    
    public Seta(String sNomeImagePNG, int direcao, Hero hHero) {
        super(sNomeImagePNG);
        this.iDirecao = direcao;
        this.auxHero = hHero;
        this.bTransponivel = true;
    }

    public void autoDesenho() {
        super.autoDesenho();
    }
    
    public int getDirecao() {
        return this.iDirecao;
    }
}
