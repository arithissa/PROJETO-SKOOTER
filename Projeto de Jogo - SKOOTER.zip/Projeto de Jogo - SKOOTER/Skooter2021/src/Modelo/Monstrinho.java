package Modelo;

import Auxiliar.Consts;
import Auxiliar.Desenhador;
import Auxiliar.Posicao;
import Controler.ControleDeJogo;
import Controler.Fase;
import Controler.Tela;
import java.awt.Graphics;
import java.io.Serializable;
import java.util.Random;


public class Monstrinho extends Elemento implements Serializable{
    Random r;
    
    public Monstrinho(String sNomeImagePNG) {
        super(sNomeImagePNG);
        this.bMortal = true;
        r = new Random();
    }

    public void autoDesenho() {        
        int iDirecao = r.nextInt(4);
        switch(iDirecao) {
            case 0:
                this.moveUp();
                break;
            case 1:
                this.moveDown();
                break;
            case 2:
                this.moveRight();
                break;
            case 3:
                this.moveLeft();
                break;
        }
        
        if(!Desenhador.getTelaDoJogo().ehPosicaoValidaGeral(this)) {
            this.getPosicao().volta();
        }
        super.autoDesenho();
    }
}
