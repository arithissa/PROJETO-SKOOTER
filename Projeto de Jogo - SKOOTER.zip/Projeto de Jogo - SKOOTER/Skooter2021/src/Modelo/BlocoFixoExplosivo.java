package Modelo;

import Auxiliar.Consts;
import Auxiliar.Desenhador;
import Controler.Tela;
import java.awt.Graphics;
import java.io.Serializable;

public class BlocoFixoExplosivo extends Elemento implements Serializable{
    
    public BlocoFixoExplosivo(String sNomeImagePNG) {
        super(sNomeImagePNG);
        this.bExplosivo = true;
    }

    public void autoDesenho() {
        super.autoDesenho();
    }    
}
