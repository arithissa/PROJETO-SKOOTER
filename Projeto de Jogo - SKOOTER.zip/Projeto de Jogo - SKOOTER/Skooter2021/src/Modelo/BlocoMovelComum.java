package Modelo;

import Auxiliar.Consts;
import Auxiliar.Desenhador;
import Controler.Tela;
import java.awt.Graphics;
import java.io.Serializable;

public class BlocoMovelComum extends Elemento implements Serializable{
    
    public BlocoMovelComum(String sNomeImagePNG) {
        super(sNomeImagePNG);
        this.bMovel = true;
    }

    public void autoDesenho() {
        super.autoDesenho();
    }    
}
