package Modelo;

import Auxiliar.Consts;
import Auxiliar.Desenhador;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.io.IOException;
import java.io.Serializable;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class Hero extends Elemento implements Serializable{
    int quantasVidas;
    int hPontos = 0;
    
    public Hero(String sNomeImagePNG, int vidas) {
        super(sNomeImagePNG);
        this.quantasVidas = vidas;
    }
    
    public int getVidas(){
        return this.quantasVidas;
    }
    
    public void setVidas(int vidas){
        this.quantasVidas = vidas;
    }
    
    public int getPontos(){
        return this.hPontos;
    }
    
    public void setPontos(int pontos){
        this.hPontos = pontos;
    }

    public void voltaAUltimaPosicao(){
        this.pPosicao.volta();
    }
    
    public boolean moveUp(){
        return this.pPosicao.moveUp();
    }
    
    public boolean moveDown(){
        return this.pPosicao.moveDown();
    }
    
    public boolean moveRight(){
        return this.pPosicao.moveRight();
    }
    
    public boolean moveLeft(){
        return this.pPosicao.moveLeft();
    }
}
